
<html>
<head>
<title>
Pharmaceutical Distribution System
</title>
    <link rel="shortcut icon" href="main/images/pos.jpg">

  <link href="main/css/bootstrap.css" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="main/css/DT_bootstrap.css">
  
  <link rel="stylesheet" href="main/css/font-awesome.min.css">
    <style type="text/css">
      body {
        padding-top: 60px;
        padding-bottom: 40px;
      }
      .sidebar-nav {
        padding: 9px 0;
      }
    </style>
    <link href="main/css/bootstrap-responsive.css" rel="stylesheet">

<link href="style.css" media="screen" rel="stylesheet" type="text/css" />
</head>
<body>
    <div class="container-fluid">
      <div class="row-fluid">
		<div class="span4">
		</div>
	
</div>
<div id="login">
<meta http-equiv="refresh" content="2; url=index.php">
<img src="main/img/logo.png" width="40%" />
			<font style=" font:bold 24px 'Aleo'; text-shadow:1px 1px 15px #000; color:#000;"><center>Pharmaceutical Distribution System</center></font>
		<br>
<?php
echo '<h3><font color="#ca1313">Invalid Username or Password</font></h3>';
		
?>
<div style="margin:0 auto; text-align:center;">
Redirecting Back Login
<br>
<img src="indicator.gif">
<br>
Please Wait
</div>
</div>
</div>
</div>
</div>
</body>
</html>