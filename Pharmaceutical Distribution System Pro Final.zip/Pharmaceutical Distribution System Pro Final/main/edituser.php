<?php
	include('../connect.php');
	$id=$_GET['id'];
	$result = $db->prepare("SELECT * FROM user WHERE id= :userid");
	$result->bindParam(':userid', $id);
	$result->execute();
	for($i=0; $row = $result->fetch(); $i++){
?>
<link href="../style.css" media="screen" rel="stylesheet" type="text/css" />
<form action="saveedituser.php" method="post">
<div id="ac">
<input type="hidden" name="memi" value="<?php echo $id; ?>" />
<span>Username : </span><input type="text" name="username" value="<?php echo $row['username']; ?>" /><br>
<span>Password : </span><input type="text" name="password" value="<?php echo $row['password']; ?>" /><br>
<span>Name : </span><input type="text" name="name" value="<?php echo $row['name']; ?>" /><br>
<span>Position : </span><input type="text" name="position" value="<?php echo $row['position']; ?>" /><br>
<span>&nbsp;</span><input id="btn" type="submit" value="save" />
</div>
</form>
<?php
}
?>