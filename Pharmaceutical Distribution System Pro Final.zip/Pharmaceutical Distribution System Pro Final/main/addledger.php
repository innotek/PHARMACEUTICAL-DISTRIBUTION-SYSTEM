<?php
function createRandomPassword() {
	$chars = "003232303232023232023456789";
	srand((double)microtime()*1000000);
	$i = 0;
	$pass = '' ;
	while ($i <= 7) {

		$num = rand() % 33;

		$tmp = substr($chars, $num, 1);

		$pass = $pass . $tmp;

		$i++;

	}
	return $pass;
}
$finalcode='IN-'.createRandomPassword();
?>
<script>

function isNumberKey(evt){  <!--Function to accept only numeric values-->
    //var e = evt || window.event;
	var charCode = (evt.which) ? evt.which : evt.keyCode
    if (charCode != 46 && charCode > 31 
	&& (charCode < 48 || charCode > 57))
        return false;
        return true;
	}
		   
    function ValidateAlpha(evt)
    {
        var keyCode = (evt.which) ? evt.which : evt.keyCode
        if ((keyCode < 65 || keyCode > 90) && (keyCode < 97 || keyCode > 123) && keyCode != 32)
         
        return false;
            return true;
    }
</script>
<link href="../style.css" media="screen" rel="stylesheet" type="text/css" />
<form action="saveledger.php" method="post">
<input type="hidden" name="name" value="<?php echo $_GET['invoice']; ?>" />
<input type="hidden" name="invoice" value="<?php echo $finalcode; ?>" />
<input type="hidden" name="tot" value="<?php echo $_GET['amount']; ?>" />
<div id="ac">
<span>Amount : </span><input type="text" style="width:265px; height:30px;" maxlength="7" onKeyPress="return isNumberKey(event)" name="amount" /><br>
<span>Remarks : </span><select name="remarks"  Required>
<option>Bill Cleared</option>
<option>Bill Not Cleared</option>

</select><br />

<span>&nbsp;</span><input id="btn" type="submit" value="save" />
</div>
</form>