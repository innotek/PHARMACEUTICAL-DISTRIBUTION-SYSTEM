<link href="../style.css" media="screen" rel="stylesheet" type="text/css" />
<script>

function isNumberKey(evt){  <!--Function to accept only numeric values-->
    //var e = evt || window.event;
	var charCode = (evt.which) ? evt.which : evt.keyCode
    if (charCode != 46 && charCode > 31 
	&& (charCode < 48 || charCode > 57))
        return false;
        return true;
	}
		   
    function ValidateAlpha(evt)
    {
        var keyCode = (evt.which) ? evt.which : evt.keyCode
        if ((keyCode < 65 || keyCode > 90) && (keyCode < 97 || keyCode > 123) && keyCode != 32)
         
        return false;
            return true;
    }
</script>
<form action="savesupplier.php" method="post">
<center><h4><i class="icon-plus-sign icon-large"></i> Add Supplier</h4></center>
<hr>
<div id="ac">
<span>Supplier Name : </span><input type="text" style="width:265px; height:30px;" onKeyPress="return ValidateAlpha(event);" name="name" required/><br>
<span>Address : </span><input type="text" style="width:265px; height:30px;" name="address" /><br>
<span>Sales Person : </span><input type="text" style="width:265px; height:30px;"onKeyPress="return ValidateAlpha(event);" name="contact" /><br>
<span>Contact No. : </span><input type="text" style="width:265px; height:30px;" onKeyPress="return isNumberKey(event)" maxlength="10" name="cperson" /><br>
<span>Note : </span><textarea style="width:265px; height:80px;" name="note" /></textarea><br>
<div style="float:right; margin-right:10px;">
<button class="btn btn-success btn-block btn-large" style="width:267px;"><i class="icon icon-save icon-large"></i> Save</button>
</div>
</div>
</form>