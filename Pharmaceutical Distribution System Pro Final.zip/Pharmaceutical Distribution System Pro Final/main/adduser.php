<link href="../style.css" media="screen" rel="stylesheet" type="text/css" />
<script>

function isNumberKey(evt){  <!--Function to accept only numeric values-->
    //var e = evt || window.event;
	var charCode = (evt.which) ? evt.which : evt.keyCode
    if (charCode != 46 && charCode > 31 
	&& (charCode < 48 || charCode > 57))
        return false;
        return true;
	}
		   
    function ValidateAlpha(evt)
    {
        var keyCode = (evt.which) ? evt.which : evt.keyCode
        if ((keyCode < 65 || keyCode > 90) && (keyCode < 97 || keyCode > 123) && keyCode != 32)
         
        return false;
            return true;
    }
</script>
<form action="saveuser.php" method="post">
<div id="ac">
<b>Add a User</b><br />
<span>Username : </span><input type="text" name="username" maxlength="15"  onKeyPress="return ValidateAlpha(event);" Required /><br>
<span>Password : </span><input type="text" name="password" Required/><br>
<span>Name : </span><input type="text" name="name" maxlength="15"  onKeyPress="return ValidateAlpha(event);"/><br>

<span>Position : </span><select name="position"  Required>
<option>admin</option>
<option>cashier</option>
</select><br />




<span>&nbsp;</span><input id="btn" type="submit" value="save" />
</div>
</form>