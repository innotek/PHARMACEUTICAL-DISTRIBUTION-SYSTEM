<?php
session_start();
include('../connect.php');
$a = $_POST['name'];
$b = $_POST['address'];
$c = $_POST['contact'];
$e = $_POST['prod_name'];

// query
$sql = "INSERT INTO customer (customer_name,address,contact,prod_name) VALUES (:a,:b,:c,:e)";
$q = $db->prepare($sql);
$q->execute(array(':a'=>$a,':b'=>$b,':c'=>$c,':e'=>$e));
header("location: customer.php");


?>